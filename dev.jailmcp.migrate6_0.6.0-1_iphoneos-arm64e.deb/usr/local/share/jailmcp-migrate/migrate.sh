#!/bin/sh
P=/var/mobile/Documents/OpenMinis-Jailbreak
B="$P/jailmcp-backup-0.6"
D=/usr/local/share/jailmcp-migrate
LOG="$P/jailmcp-migrate-0.6.log"
mkdir -p "$B"
{
  echo "[*] backup"
  [ -d "$P/.bridge-state" ] && cp -a "$P/.bridge-state" "$B/"
  [ -d /usr/local/lib/openminis-jb ] && cp -a /usr/local/lib/openminis-jb "$B/runtime"
  [ -f /Library/LaunchDaemons/app.openminis.jbbridge.plist ] && cp -a /Library/LaunchDaemons/app.openminis.jbbridge.plist "$B/"
  sleep 8
  echo "[*] removing old 0.5"
  dpkg -r --force-depends dev.jailmcp.frida-cli || echo "[!] frida remove nonzero"
  dpkg -r --force-depends dev.jailmcp.bridge || echo "[!] bridge remove nonzero"
  echo "[*] unpacking 0.6"
  dpkg --unpack "$D/JailMCP_0.6.0+experimental_iphoneos-arm64e.deb" || exit 1
  mkdir -p "$P/.jailmcp"
  if [ -d "$B/.bridge-state" ]; then cp -a "$B/.bridge-state/." "$P/.jailmcp/"; fi
  chown -R mobile:mobile "$P/.jailmcp" 2>/dev/null || true
  dpkg --configure dev.jailmcp.bridge || exit 1
  echo "[*] unpacking frida client"
  dpkg --unpack "$D/dev.jailmcp.frida-cli_17.17.0-2_iphoneos-arm64e.deb" || exit 1
  dpkg --configure dev.jailmcp.frida-cli || exit 1
  rm -f /Library/LaunchDaemons/app.openminis.jbbridge.plist
  launchctl kickstart -k system/dev.jailmcp.bridge 2>/dev/null || true
  echo "[*] installed"
  dpkg-query -W dev.jailmcp.bridge dev.jailmcp.frida-cli
  echo "[*] done"
} >> "$LOG" 2>&1
